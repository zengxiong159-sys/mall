COMMENT ON COLUMN pms_sku_stock.max_integral_deduct IS '最大抵扣积分量';
COMMENT ON COLUMN ods_pms_sku_stock.max_integral_deduct IS '最大抵扣积分量';
COMMENT ON COLUMN oms_order.integral_deduct IS '积分抵扣金额';
COMMENT ON COLUMN ods_oms_order.integral_deduct IS '积分抵扣金额';
COMMENT ON COLUMN oms_order_refund.integral_deduct IS '积分抵扣金额';
COMMENT ON COLUMN ods_oms_order_refund.integral_deduct IS '积分抵扣金额';