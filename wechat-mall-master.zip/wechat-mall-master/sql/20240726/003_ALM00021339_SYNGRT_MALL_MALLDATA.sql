CREATE or replace PUBLIC SYNONYM USER_WHITE_NAME_CONFIG FOR USER_WHITE_NAME_CONFIG;
grant select,insert,update,delete on USER_WHITE_NAME_CONFIG to amallopr;
grant select on USER_WHITE_NAME_CONFIG to qdbankcx;