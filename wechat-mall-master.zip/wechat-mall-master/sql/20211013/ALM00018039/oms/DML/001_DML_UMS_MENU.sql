INSERT INTO UMS_MENU VALUES (34,8,1,0,   '用户优惠券查询','daohangweixuanzhong', 'usercoupons', sysdate, sysdate, '系统管理员',  '系统管理员');

COMMIT;