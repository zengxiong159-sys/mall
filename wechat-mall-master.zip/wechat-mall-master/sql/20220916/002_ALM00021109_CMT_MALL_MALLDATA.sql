COMMENT ON COLUMN pms_product.product_attr IS '商品属性： 0 常规商品 1 分期商品';
