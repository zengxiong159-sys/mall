COMMENT ON COLUMN pms_sku_stock.min_integral_deduct IS '最小抵扣积分量';
COMMENT ON COLUMN CMS_PREFECTURE_STOCK_RELATION.product_level IS '商品优先级';