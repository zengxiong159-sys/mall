insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773247467520', '101464407145578496', '209727904175628288', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773260050432', '101464407145578496', '209728075588444160', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773264244736', '101464407145578496', '209728242911813632', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773268439040', '101464407145578496', '209728325711568896', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773272633344', '101464407145578496', '209728505911451648', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773281021952', '101464407145578496', '209728628527734784', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773289410560', '101464407145578496', '210446931197976576', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773297799168', '101464407145578496', '210447180398354432', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773306187776', '101464407145578496', '210447440189349888', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773310382080', '101464407145578496', '210447705172893696', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773314576384', '101464407145578496', '210448901350645760', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773322964992', '101464407145578496', '210449034473660416', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773327159296', '101464407145578496', '210449198852628480', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773331353600', '101464407145578496', '210449341408632832', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773343936512', '101464407145578496', '210449517737172992', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773348130816', '101464407145578496', '210534042664198144', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773352325120', '101464407145578496', '210534141402308608', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773360713728', '101464407145578496', '210534350375116800', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773364908032', '101464407145578496', '210534559855435776', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773369102336', '101464407145578496', '210534748490063872', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773373296640', '101464407145578496', '210535095807795200', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773377490944', '101464407145578496', '210535183850430464', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773385879552', '101464407145578496', '210535772055429120', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773390073856', '101464407145578496', '210535851537489920', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773398462464', '101464407145578496', '210537010268495872', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773402656768', '101464407145578496', '210537090610388992', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773411045376', '101464407145578496', '210537173456281600', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773415239680', '101464407145578496', '210537347331153920', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773423628288', '101464407145578496', '210537593012510720', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773427822592', '101464407145578496', '210537683789832192', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773432016896', '101464407145578496', '216684302876803072', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773440405504', '101464407145578496', '210445460834377728', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773448794112', '101464407145578496', '210445612672376832', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773457182720', '101464407145578496', '210453371228807168', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773461377024', '101464407145578496', '210453499515789312', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773465571328', '101464407145578496', '210453637428699136', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773478154240', '101464407145578496', '210453736842092544', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773482348544', '101464407145578496', '210458597818130432', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773490737152', '101464407145578496', '210458738662858752', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773494931456', '101464407145578496', '210459781639462912', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773499125760', '101464407145578496', '210466984232509440', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773503320064', '101464407145578496', '210474028914204672', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773511708672', '101464407145578496', '210474150217670656', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773515902976', '101464407145578496', '212705537658216448', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773520097280', '101464407145578496', '210563098617081856', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773524291584', '101464407145578496', '210533391175540736', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773532680192', '101464407145578496', '210533531533729792', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773536874496', '101464407145578496', '210533717043601408', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773541068800', '101464407145578496', '210533847037665280', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773545263104', '101464407145578496', '210534263938899968', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773553651712', '101464407145578496', '210535544199864320', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773557846016', '101464407145578496', '210537812378804224', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773562040320', '101464407145578496', '210538071872004096', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773566234624', '101464407145578496', '210538181754380288', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773570428928', '101464407145578496', '210539156128948224', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773578817536', '101464407145578496', '210459634650079232', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773583011840', '101464407145578496', '210204664658944000', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773587206144', '101464407145578496', '210205011838263296', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773591400448', '101464407145578496', '210445024354131968', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773595594752', '101464407145578496', '210445290847625216', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773599789056', '101464407145578496', '210454811909316608', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773608177664', '101464407145578496', '210465992627740672', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773612371968', '101464407145578496', '210466130066694144', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773616566272', '101464407145578496', '210466254851432448', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773620760576', '101464407145578496', '210466355015606272', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773624954880', '101464407145578496', '210468179512680448', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773629149184', '101464407145578496', '210468436908728320', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773633343488', '101464407145578496', '210468560015745024', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773641732096', '101464407145578496', '210468751158566912', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773645926400', '101464407145578496', '210469367121469440', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773650120704', '101464407145578496', '210469484067053568', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773654315008', '101464407145578496', '210469619111059456', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773662703616', '101464407145578496', '210469752523481088', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773666897920', '101464407145578496', '210475374937661440', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773671092224', '101464407145578496', '210475560049074176', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773679480832', '101464407145578496', '210475757965697024', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773683675136', '101464407145578496', '210475903369633792', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773687869440', '101464407145578496', '210476137868976128', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773692063744', '101464407145578496', '210539672435187712', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773696258048', '101464407145578496', '210538272082911232', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773704646656', '101464407145578496', '210538570692190208', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773708840960', '101464407145578496', '210539253323554816', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773713035264', '101464407145578496', '210539333522841600', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773717229568', '101464407145578496', '210539434840449024', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773725618176', '101464407145578496', '210539535910592512', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773729812480', '101464407145578496', '210539858930720768', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('216708773734006784', '101464407145578496', '210539993752428544', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_role_resource_relation (ID, ROLE_ID, RESOURCE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('207809793142437491', '101464407145578496', '217084944636182528', to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-01-2022 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');
