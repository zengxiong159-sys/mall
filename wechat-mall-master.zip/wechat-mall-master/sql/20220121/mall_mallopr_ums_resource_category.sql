insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727139591757824', '订单管理', '0', to_date('29-12-2021 09:53:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:10', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727355069931520', '系统管理', '0', to_date('29-12-2021 09:54:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:54:02', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727186853175296', '运营管理', '0', to_date('29-12-2021 09:53:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:21', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727216431407104', '营销管理', '0', to_date('29-12-2021 09:53:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:28', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727252540170240', '商户管理', '0', to_date('29-12-2021 09:53:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:37', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727289722675200', '商品管理', '0', to_date('29-12-2021 09:53:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:46', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727319300907008', '财务管理', '0', to_date('29-12-2021 09:53:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:53:53', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');

insert into ums_resource_category (ID, NAME, SORT, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('209727387118608384', '配置管理', '0', to_date('29-12-2021 09:54:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-12-2021 09:54:09', 'dd-mm-yyyy hh24:mi:ss'), '吴鹏举', '吴鹏举');
