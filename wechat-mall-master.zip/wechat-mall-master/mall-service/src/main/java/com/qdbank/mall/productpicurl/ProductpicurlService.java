package com.qdbank.mall.productpicurl;

public interface ProductpicurlService {
    public void deletePicUrl();
}
