package com.qdbank.mall.time;

import com.qdbank.mall.model.TimeDO;

public interface TimeService {
    /**
     * 时间处理
     * @param time
     */
    public void setTime(TimeDO time);
}
