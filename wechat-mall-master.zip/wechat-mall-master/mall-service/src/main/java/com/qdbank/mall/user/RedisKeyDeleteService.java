package com.qdbank.mall.user;

public interface RedisKeyDeleteService {
    public void deletePattern(String pattern);
}
