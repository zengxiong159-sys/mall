package com.qdbank.mall.task;

import com.qdbank.mall.api.CommonResult;

import java.util.Map;

public interface TaskService {
    public void task(Map<String,String> params);
}
