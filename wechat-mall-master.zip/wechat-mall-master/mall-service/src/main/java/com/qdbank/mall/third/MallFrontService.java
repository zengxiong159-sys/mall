package com.qdbank.mall.third;

import java.util.Map;

public interface MallFrontService {
    Map sendFront(String url, Object params);
}
