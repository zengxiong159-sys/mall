package com.qdbank.mall.replace;

public interface ReplaceService {
    public String replaceUrl(String replaceUrl);
    public String replaceOmsUrl(String replaceUrl);
}
