package com.qdbank.mall.enums;

public enum LimitType {
    MOBILE
}
