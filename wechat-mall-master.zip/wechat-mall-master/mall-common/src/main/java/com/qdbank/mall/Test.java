package com.qdbank.mall;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by ningyh on 2020/10/25 上午10:39
 * <p>
 * describe：
 */
public class Test extends Thread{

}
