package com.qdbank.mall.bo;

import lombok.Data;

/**
 * 用户信息
 */
@Data
public class UserDetails {


    private String custNo;

    private String custName;

    private String custMobile;






}
