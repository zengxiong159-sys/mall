package com.qdbank.mall.position;

import com.qdbank.mall.response.position.PositionResDTO;

import java.util.List;

public interface PositionService {
    public List<PositionResDTO> list();
}
