package com.qdbank.mall.bo;

import lombok.Data;

import java.util.Map;

@Data
public class VirtualConfig {

    private Map categegoty;

    private String type;

}
