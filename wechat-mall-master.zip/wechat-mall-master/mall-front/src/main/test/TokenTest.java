import com.qdbank.mall.util.JsonUtil;
import com.qdbank.mall.util.JwtTokenUtil;

import java.util.HashMap;
import java.util.Map;

public class TokenTest {

    public static void main(String[] args) {

        /**
         * tokenHeader: Authorization #JWT�洢������ͷ
         *   secret: mall-front-secret #JWT�ӽ���ʹ�õ���Կ
         *   expiration: 604800 #JWT�ĳ�����ʱ��(60*60*24*7)
         *   tokenHead: 'Bearer '  #JWT�������õ���ͷ
         */

        String json = "{\"custMobile\":\"15934960263\",\"custNo\":\"7\"}";
        Map map = JsonUtil.parseObject(json,Map.class);

        JwtTokenUtil jwtTokenUtil = new JwtTokenUtil();
        jwtTokenUtil.setTokenHead("Bearer ");
        jwtTokenUtil.setExpiration(604800L);
        jwtTokenUtil.setSecret("mall-front-secret");
        String s =jwtTokenUtil.generateFrontToken(map);
        System.out.println(s);



    }


}
