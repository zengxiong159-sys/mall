prompt Importing table PMS_PRODUCT_CATEGORY...
set feedback off
set define off
insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619569144037376', '0', '�������', '0', '0', '0', to_date('28-02-2021 13:45:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:45:00', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619762665029632', '0', 'Ьѥ���', '0', '0', '0', to_date('28-02-2021 13:45:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:45:46', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619799977558016', '0', '������ױ', '0', '0', '0', to_date('28-02-2021 13:45:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:45:55', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619840473563136', '0', '�Ӽ�����', '0', '0', '0', to_date('28-02-2021 13:46:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:46:04', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619880101347328', '0', '���õ���', '0', '0', '0', to_date('28-02-2021 13:46:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:46:14', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99619923394953216', '0', '������ʳ', '0', '0', '0', to_date('28-02-2021 13:46:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:46:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620061278502912', '0', '��ȯ', '0', '0', '1', to_date('28-02-2021 13:46:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:46:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620494629797888', '0', '�ճ���ֵ', '0', '0', '1', to_date('28-02-2021 13:48:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:48:40', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620525101416448', '0', '���ֳ�ֵ', '0', '0', '1', to_date('28-02-2021 13:48:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:48:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620552829960192', '0', '���γ���', '0', '0', '1', to_date('28-02-2021 13:48:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:48:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620898801319936', '99619569144037376', 'ͨѶ�豸', '1', '0', '0', to_date('28-02-2021 13:50:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:50:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620962114338816', '99619569144037376', '��Ϣ�豸', '1', '0', '0', to_date('28-02-2021 13:50:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:50:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99620992846004224', '99619569144037376', '����������豸', '1', '0', '0', to_date('28-02-2021 13:50:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:50:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621153290715136', '99619762665029632', '���', '1', '0', '0', to_date('28-02-2021 13:51:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:51:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621249113784320', '99619799977558016', 'ȫ������', '1', '0', '0', to_date('28-02-2021 13:51:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:51:40', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621277232398336', '99619799977558016', '��ʿ����', '1', '0', '0', to_date('28-02-2021 13:51:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:51:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621376415105024', '99619799977558016', '��ױ/��ױ/���', '1', '0', '0', to_date('28-02-2021 13:52:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:52:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621414344196096', '99619799977558016', '���ݻ�������', '1', '0', '0', to_date('28-02-2021 13:52:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:52:20', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621496766464000', '99619840473563136', '������Ʒ', '1', '0', '0', to_date('28-02-2021 13:52:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:52:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621532401270784', '99619840473563136', '���߲;�', '1', '0', '0', to_date('28-02-2021 13:52:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:52:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621594699268096', '99619840473563136', '��������', '1', '0', '0', to_date('28-02-2021 13:53:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:53:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621662143676416', '99619880101347328', '����С��', '1', '0', '0', to_date('28-02-2021 13:53:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:53:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621715381977088', '99619880101347328', '�������', '1', '0', '0', to_date('28-02-2021 13:53:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:53:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621777512202240', '99619923394953216', '����/��Ҷ/����/����', '1', '0', '0', to_date('28-02-2021 13:53:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:53:46', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621816988991488', '99619923394953216', 'ţ����Ʒ', '1', '0', '0', to_date('28-02-2021 13:53:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:53:56', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621846110044160', '99619923394953216', '����', '1', '0', '0', to_date('28-02-2021 13:54:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:54:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621879551229952', '99619923394953216', '���͸ɻ���ζƷ', '1', '0', '0', to_date('28-02-2021 13:54:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:54:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621904318595072', '99619923394953216', '��������', '1', '0', '0', to_date('28-02-2021 13:54:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:54:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99621937814306816', '99619923394953216', '������ʳ', '1', '0', '0', to_date('28-02-2021 13:54:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:54:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622444788219904', '99620061278502912', '��Ʒȯ', '1', '0', '1', to_date('28-02-2021 13:56:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:56:25', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622466011398144', '99620061278502912', '��ֵȯ', '1', '0', '1', to_date('28-02-2021 13:56:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:56:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622615047602176', '99620494629797888', '����', '1', '0', '1', to_date('28-02-2021 13:57:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:57:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622655812042752', '99620494629797888', '�Ϳ�', '1', '0', '1', to_date('28-02-2021 13:57:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:57:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622718214897664', '99620525101416448', '��Ա��ֵ', '1', '0', '1', to_date('28-02-2021 13:57:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:57:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99622786640773120', '99620552829960192', 'Ʊ��', '1', '0', '1', to_date('28-02-2021 13:57:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 13:57:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624035918413824', '99620898801319936', '�ֻ�ͨѶ', '2', '0', '0', to_date('28-02-2021 14:02:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:02:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624632553963520', '99621249113784320', '��������', '2', '0', '0', to_date('28-02-2021 14:05:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:07', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624180202471424', '99620962114338816', '��������', '2', '0', '0', to_date('28-02-2021 14:03:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:03:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624235982520320', '99620962114338816', '�������', '2', '0', '0', to_date('28-02-2021 14:03:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:03:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624355302080512', '99620992846004224', '�����豸', '2', '0', '0', to_date('28-02-2021 14:04:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:04:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624486604767232', '99621153290715136', '�������', '2', '0', '0', to_date('28-02-2021 14:04:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:04:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624609556594688', '99621249113784320', 'ͷ������', '2', '0', '0', to_date('28-02-2021 14:05:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624660945207296', '99621249113784320', '���廤��', '2', '0', '0', to_date('28-02-2021 14:05:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:14', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624730490961920', '99621249113784320', '�ڱ�ǻ����', '2', '0', '0', to_date('28-02-2021 14:05:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624805090852864', '99621277232398336', '�沿����', '2', '0', '0', to_date('28-02-2021 14:05:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624831728877568', '99621277232398336', '����/ͷ������', '2', '0', '0', to_date('28-02-2021 14:05:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:05:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624906672701440', '99621376415105024', '���', '2', '0', '0', to_date('28-02-2021 14:06:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:12', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624930760589312', '99621376415105024', '��ױ', '2', '0', '0', to_date('28-02-2021 14:06:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624956001910784', '99621376415105024', '����', '2', '0', '0', to_date('28-02-2021 14:06:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99624977195728896', '99621376415105024', '��ױ����', '2', '0', '0', to_date('28-02-2021 14:06:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625053129408512', '99621414344196096', '��ǻ��������', '2', '0', '0', to_date('28-02-2021 14:06:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625075493437440', '99621414344196096', '��������', '2', '0', '0', to_date('28-02-2021 14:06:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625100185305088', '99621414344196096', '��������', '2', '0', '0', to_date('28-02-2021 14:06:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:06:58', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625130967302144', '99621414344196096', '���ݹ���', '2', '0', '0', to_date('28-02-2021 14:07:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625195123376128', '99621496766464000', '������', '2', '0', '0', to_date('28-02-2021 14:07:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625221471993856', '99621496766464000', '��о/��ͷ', '2', '0', '0', to_date('28-02-2021 14:07:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625252157521920', '99621496766464000', '��о', '2', '0', '0', to_date('28-02-2021 14:07:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625289184837632', '99621496766464000', '̺��/����', '2', '0', '0', to_date('28-02-2021 14:07:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:43', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625345694695424', '99621532401270784', '�;�', '2', '0', '0', to_date('28-02-2021 14:07:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:07:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625367228252160', '99621532401270784', '����', '2', '0', '0', to_date('28-02-2021 14:08:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:02', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625390234009600', '99621532401270784', '����', '2', '0', '0', to_date('28-02-2021 14:08:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:08', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625413969575936', '99621532401270784', '��������', '2', '0', '0', to_date('28-02-2021 14:08:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:13', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625451349213184', '99621532401270784', '���ɱ���', '2', '0', '0', to_date('28-02-2021 14:08:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:22', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625531233927168', '99621594699268096', '��ౣ��', '2', '0', '0', to_date('28-02-2021 14:08:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625558392045568', '99621594699268096', 'ֽ��Ʒ', '2', '0', '0', to_date('28-02-2021 14:08:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625582047920128', '99621594699268096', '��ԡ��Ʒ', '2', '0', '0', to_date('28-02-2021 14:08:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:08:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625689640206336', '99621662143676416', 'ʳ��ӹ�', '2', '0', '0', to_date('28-02-2021 14:09:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:09:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625717217755136', '99621662143676416', 'ʳ�����', '2', '0', '0', to_date('28-02-2021 14:09:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:09:25', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625744870801408', '99621662143676416', '��Ʒ�豸', '2', '0', '0', to_date('28-02-2021 14:09:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:09:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625804715130880', '99621715381977088', '�������', '2', '0', '0', to_date('28-02-2021 14:09:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:09:46', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625863288586240', '99621715381977088', '��ˮ��', '2', '0', '0', to_date('28-02-2021 14:10:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:00', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625885447094272', '99621715381977088', '��������', '2', '0', '0', to_date('28-02-2021 14:10:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625913897058304', '99621715381977088', '�¶ȵ���', '2', '0', '0', to_date('28-02-2021 14:10:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:12', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625961733095424', '99621777512202240', '��', '2', '0', '0', to_date('28-02-2021 14:10:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99625986387214336', '99621777512202240', '����', '2', '0', '0', to_date('28-02-2021 14:10:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626008499585024', '99621777512202240', '���', '2', '0', '0', to_date('28-02-2021 14:10:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626034286166016', '99621777512202240', '����', '2', '0', '0', to_date('28-02-2021 14:10:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626058474717184', '99621777512202240', '����ˮ', '2', '0', '0', to_date('28-02-2021 14:10:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:10:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633105559748608', '99624930760589312', '�۱�', '3', '0', '0', to_date('28-02-2021 14:38:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:38:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632865821720576', '99624930760589312', '���˪', '3', '0', '0', to_date('28-02-2021 14:37:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:37:50', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632883953696768', '99624930760589312', '����/���߱�', '3', '0', '0', to_date('28-02-2021 14:37:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:37:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632904472231936', '99624930760589312', '����/����', '3', '0', '0', to_date('28-02-2021 14:37:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:37:59', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633005194248192', '99624930760589312', '����/�ں�', '3', '0', '0', to_date('28-02-2021 14:38:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:38:23', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633022873239552', '99624930760589312', '��ױ��', '3', '0', '0', to_date('28-02-2021 14:38:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:38:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633042733268992', '99624930760589312', '�۵�Һ/��', '3', '0', '0', to_date('28-02-2021 14:38:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:38:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633140577992704', '99624930760589312', '��׸���', '3', '0', '0', to_date('28-02-2021 14:38:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:38:55', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633169128620032', '99624930760589312', '�۷�/ɢ��', '3', '0', '0', to_date('28-02-2021 14:39:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:02', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633200581705728', '99624930760589312', 'ü��/ü��/ü��', '3', '0', '0', to_date('28-02-2021 14:39:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:10', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633222991872000', '99624930760589312', '����/��֬', '3', '0', '0', to_date('28-02-2021 14:39:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:15', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633252708515840', '99624930760589312', '����/�߹�/��Ӱ��', '3', '0', '0', to_date('28-02-2021 14:39:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:22', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633273591955456', '99624930760589312', '����', '3', '0', '0', to_date('28-02-2021 14:39:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633293280018432', '99624930760589312', '��ë��/��ë����Һ', '3', '0', '0', to_date('28-02-2021 14:39:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633313312014336', '99624930760589312', '��Ӱ', '3', '0', '0', to_date('28-02-2021 14:39:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633329212620800', '99624930760589312', '��覱�', '3', '0', '0', to_date('28-02-2021 14:39:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:40', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99633350930726912', '99624930760589312', '��װ', '3', '0', '0', to_date('28-02-2021 14:39:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:39:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636306811944960', '99624956001910784', 'ָ����', '3', '0', '0', to_date('28-02-2021 14:51:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:51:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636327552778240', '99624956001910784', 'ϴ��ˮ', '3', '0', '0', to_date('28-02-2021 14:51:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:51:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636350571118592', '99624956001910784', '��������', '3', '0', '0', to_date('28-02-2021 14:51:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:51:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636369621647360', '99624956001910784', '�����ܱ�', '3', '0', '0', to_date('28-02-2021 14:51:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:51:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636419559030784', '99624977195728896', '��ױ��', '3', '0', '0', to_date('28-02-2021 14:51:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:51:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636445123313664', '99624977195728896', '��������', '3', '0', '0', to_date('28-02-2021 14:52:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636460961005568', '99624977195728896', '������װ', '3', '0', '0', to_date('28-02-2021 14:52:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:07', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636479382388736', '99624977195728896', '��ױ��/��ǩ', '3', '0', '0', to_date('28-02-2021 14:52:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636547216867328', '99625053129408512', '������', '3', '0', '0', to_date('28-02-2021 14:52:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:28', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636565428535296', '99625053129408512', '����������', '3', '0', '0', to_date('28-02-2021 14:52:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636585817047040', '99625053129408512', '�綯��ˢ', '3', '0', '0', to_date('28-02-2021 14:52:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636629383282688', '99625075493437440', '�紵��', '3', '0', '0', to_date('28-02-2021 14:52:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636649943760896', '99625075493437440', '��/ֱ����', '3', '0', '0', to_date('28-02-2021 14:52:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636670688788480', '99625075493437440', '������', '3', '0', '0', to_date('28-02-2021 14:52:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:52:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636756609105920', '99625100185305088', '�綯�޽���', '3', '0', '0', to_date('28-02-2021 14:53:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:53:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636773021417472', '99625100185305088', '��ë/��ë��', '3', '0', '0', to_date('28-02-2021 14:53:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:53:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636950784409600', '99625130967302144', '�沿�����', '3', '0', '0', to_date('28-02-2021 14:54:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:04', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636976680042496', '99625130967302144', '�綯���뵶/�����޼���', '3', '0', '0', to_date('28-02-2021 14:54:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:10', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99636997857083392', '99625130967302144', '����������', '3', '0', '0', to_date('28-02-2021 14:54:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:15', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637042639667200', '99625195123376128', '��ϯ/����', '3', '0', '0', to_date('28-02-2021 14:54:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637066589143040', '99625195123376128', '��Ʒ�׼�', '3', '0', '0', to_date('28-02-2021 14:54:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637136185229312', '99625221471993856', '������', '3', '0', '0', to_date('28-02-2021 14:54:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637153755168768', '99625221471993856', '�齺��', '3', '0', '0', to_date('28-02-2021 14:54:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637177813696512', '99625221471993856', '������', '3', '0', '0', to_date('28-02-2021 14:54:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:54:58', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637246868717568', '99625252157521920', '���ޱ�', '3', '0', '0', to_date('28-02-2021 14:55:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:14', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637270604283904', '99625252157521920', '��ë��/��ë��', '3', '0', '0', to_date('28-02-2021 14:55:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:20', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637324085854208', '99625252157521920', '��˿��', '3', '0', '0', to_date('28-02-2021 14:55:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:33', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637341844537344', '99625252157521920', '�ޱ�', '3', '0', '0', to_date('28-02-2021 14:55:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637367257825280', '99625252157521920', '�ϳ���ά��', '3', '0', '0', to_date('28-02-2021 14:55:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:43', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637387017191424', '99625252157521920', '��о����', '3', '0', '0', to_date('28-02-2021 14:55:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637429614542848', '99625289184837632', '̺��', '3', '0', '0', to_date('28-02-2021 14:55:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:55:58', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637449856253952', '99625289184837632', '����/����', '3', '0', '0', to_date('28-02-2021 14:56:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637507108503552', '99625345694695424', '�;���װ', '3', '0', '0', to_date('28-02-2021 14:56:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637524561002496', '99625345694695424', '�;ߵ�Ʒ', '3', '0', '0', to_date('28-02-2021 14:56:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637546497212416', '99625345694695424', 'һ���Բ;�', '3', '0', '0', to_date('28-02-2021 14:56:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637600607928320', '99625367228252160', 'ˮ��', '3', '0', '0', to_date('28-02-2021 14:56:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637621621391360', '99625367228252160', '���', '3', '0', '0', to_date('28-02-2021 14:56:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:44', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637638474104832', '99625367228252160', '�ƾ�', '3', '0', '0', to_date('28-02-2021 14:56:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637655926603776', '99625367228252160', '���Ⱦ�', '3', '0', '0', to_date('28-02-2021 14:56:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:56:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637703016054784', '99625390234009600', '����ֹ�', '3', '0', '0', to_date('28-02-2021 14:57:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637735261863936', '99625390234009600', '����', '3', '0', '0', to_date('28-02-2021 14:57:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637755017035776', '99625390234009600', '������', '3', '0', '0', to_date('28-02-2021 14:57:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637771030888448', '99625390234009600', '������', '3', '0', '0', to_date('28-02-2021 14:57:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637786981826560', '99625390234009600', 'Ϳ���', '3', '0', '0', to_date('28-02-2021 14:57:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:23', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637803788402688', '99625390234009600', '������', '3', '0', '0', to_date('28-02-2021 14:57:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637823140921344', '99625390234009600', '�ǽ�����', '3', '0', '0', to_date('28-02-2021 14:57:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637841050599424', '99625390234009600', '��������', '3', '0', '0', to_date('28-02-2021 14:57:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:36', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637884629417984', '99625413969575936', '����', '3', '0', '0', to_date('28-02-2021 14:57:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:46', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637900077039616', '99625413969575936', '��������', '3', '0', '0', to_date('28-02-2021 14:57:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:57:50', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637946096943104', '99625451349213184', '��������/Ĥ/��', '3', '0', '0', to_date('28-02-2021 14:58:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637966036664320', '99625451349213184', '��������', '3', '0', '0', to_date('28-02-2021 14:58:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99637989407326208', '99625451349213184', '��Я����', '3', '0', '0', to_date('28-02-2021 14:58:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638042553352192', '99625531233927168', '���Һ/��', '3', '0', '0', to_date('28-02-2021 14:58:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638075369586688', '99625531233927168', '�Ҿӱ���', '3', '0', '0', to_date('28-02-2021 14:58:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638094726299648', '99625531233927168', '��๤��', '3', '0', '0', to_date('28-02-2021 14:58:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638115194503168', '99625531233927168', '��Ʒ����', '3', '0', '0', to_date('28-02-2021 14:58:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638156323848192', '99625558392045568', 'ֽƷʪ��', '3', '0', '0', to_date('28-02-2021 14:58:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:58:51', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638216411447296', '99625582047920128', 'ë��/ԡ��/ԡ��', '3', '0', '0', to_date('28-02-2021 14:59:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638264419450880', '99625689640206336', '������/������', '3', '0', '0', to_date('28-02-2021 14:59:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638304386973696', '99625689640206336', '������', '3', '0', '0', to_date('28-02-2021 14:59:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638322774802432', '99625689640206336', 'ե�ͻ�', '3', '0', '0', to_date('28-02-2021 14:59:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638338838986752', '99625689640206336', '����ܻ�', '3', '0', '0', to_date('28-02-2021 14:59:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638354290802688', '99625689640206336', '���߻�', '3', '0', '0', to_date('28-02-2021 14:59:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:38', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638373328748544', '99625689640206336', 'ʳ�ﴦ������', '3', '0', '0', to_date('28-02-2021 14:59:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:43', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638392811290624', '99625689640206336', '�Ʊڻ�', '3', '0', '0', to_date('28-02-2021 14:59:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:59:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638493084516352', '99625717217755136', '�緹��/��ѹ����', '3', '0', '0', to_date('28-02-2021 15:00:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638516392263680', '99625717217755136', '΢��¯', '3', '0', '0', to_date('28-02-2021 15:00:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638532947181568', '99625717217755136', '���/����¯', '3', '0', '0', to_date('28-02-2021 15:00:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638554367492096', '99625717217755136', '�����', '3', '0', '0', to_date('28-02-2021 15:00:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638571455086592', '99625717217755136', '������', '3', '0', '0', to_date('28-02-2021 15:00:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638590232985600', '99625717217755136', '������', '3', '0', '0', to_date('28-02-2021 15:00:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638617533710336', '99625717217755136', '�����/�տ���', '3', '0', '0', to_date('28-02-2021 15:00:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638647099359232', '99625717217755136', '����ը��', '3', '0', '0', to_date('28-02-2021 15:00:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638663863992320', '99625717217755136', 'ʳ����������', '3', '0', '0', to_date('28-02-2021 15:00:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638684340584448', '99625717217755136', '�翾��/������/������', '3', '0', '0', to_date('28-02-2021 15:00:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:00:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638772844593152', '99625744870801408', 'ե֭/ԭ֭��', '3', '0', '0', to_date('28-02-2021 15:01:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638800543776768', '99625744870801408', '������', '3', '0', '0', to_date('28-02-2021 15:01:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:25', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638818503786496', '99625744870801408', '��ˮ��/��ˮ��', '3', '0', '0', to_date('28-02-2021 15:01:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638839777296384', '99625744870801408', '���Ȼ�', '3', '0', '0', to_date('28-02-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638858102210560', '99625744870801408', '��Ʒ�ӹ�����', '3', '0', '0', to_date('28-02-2021 15:01:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638910925275136', '99625804715130880', '������', '3', '0', '0', to_date('28-02-2021 15:01:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:51', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638930227462144', '99625804715130880', '�ٶ�/���̻�', '3', '0', '0', to_date('28-02-2021 15:01:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:01:56', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638967745511424', '99625804715130880', '���һ�', '3', '0', '0', to_date('28-02-2021 15:02:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:05', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99638984824717312', '99625804715130880', '�ӻ�����', '3', '0', '0', to_date('28-02-2021 15:02:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:09', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639037928800256', '99625863288586240', '��ˮ��', '3', '0', '0', to_date('28-02-2021 15:02:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639060640956416', '99625863288586240', '��ˮ��', '3', '0', '0', to_date('28-02-2021 15:02:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639081222406144', '99625863288586240', '��ˮ��', '3', '0', '0', to_date('28-02-2021 15:02:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639138046836736', '99625885447094272', '������', '3', '0', '0', to_date('28-02-2021 15:02:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639154400428032', '99625885447094272', '��ʪ��', '3', '0', '0', to_date('28-02-2021 15:02:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:49', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639174822494208', '99625885447094272', '��ʪ��', '3', '0', '0', to_date('28-02-2021 15:02:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:02:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639230157946880', '99625913897058304', '��ů����', '3', '0', '0', to_date('28-02-2021 15:03:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:03:07', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639248302505984', '99625913897058304', 'ȡů��', '3', '0', '0', to_date('28-02-2021 15:03:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:03:12', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99639270721060864', '99625913897058304', '�����豸', '3', '0', '0', to_date('28-02-2021 15:03:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:03:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99642979458875392', '99625961733095424', '���ݲ�', '3', '0', '0', to_date('28-02-2021 15:18:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99642997787983872', '99625961733095424', 'ˮ����/��ζ��', '3', '0', '0', to_date('28-02-2021 15:18:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:05', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643019497701376', '99625961733095424', '���', '3', '0', '0', to_date('28-02-2021 15:18:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643036102950912', '99625961733095424', '�̲�', '3', '0', '0', to_date('28-02-2021 15:18:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:15', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643053614170112', '99625961733095424', '������', '3', '0', '0', to_date('28-02-2021 15:18:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643070684987392', '99625961733095424', '��/��/�Ʋ�', '3', '0', '0', to_date('28-02-2021 15:18:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:23', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643096228298752', '99625961733095424', '��ϵ�ζ��', '3', '0', '0', to_date('28-02-2021 15:18:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643164809363456', '99625986387214336', '���ܿ���', '3', '0', '0', to_date('28-02-2021 15:18:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643181691437056', '99625986387214336', '���Ȱ���', '3', '0', '0', to_date('28-02-2021 15:18:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:49', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643200054099968', '99625986387214336', '���ȶ�/��', '3', '0', '0', to_date('28-02-2021 15:18:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:18:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643313807818752', '99626008499585024', '��Ƭ������', '3', '0', '0', to_date('28-02-2021 15:19:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643340382928896', '99626008499585024', '����/��������', '3', '0', '0', to_date('28-02-2021 15:19:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643367322943488', '99626008499585024', '������', '3', '0', '0', to_date('28-02-2021 15:19:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:34', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643385870155776', '99626008499585024', '�����̷�', '3', '0', '0', to_date('28-02-2021 15:19:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:38', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643403029053440', '99626008499585024', '��������', '3', '0', '0', to_date('28-02-2021 15:19:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:42', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643449610993664', '99626034286166016', '�߹�֭', '3', '0', '0', to_date('28-02-2021 15:19:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643473157816320', '99626034286166016', '��������', '3', '0', '0', to_date('28-02-2021 15:19:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:19:59', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643501762969600', '99626034286166016', '̼������', '3', '0', '0', to_date('28-02-2021 15:20:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643526240927744', '99626034286166016', '��������', '3', '0', '0', to_date('28-02-2021 15:20:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643542766485504', '99626034286166016', '��ζ����', '3', '0', '0', to_date('28-02-2021 15:20:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:15', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643557694013440', '99626034286166016', 'ֲ������', '3', '0', '0', to_date('28-02-2021 15:20:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643573934358528', '99626034286166016', '��/��������', '3', '0', '0', to_date('28-02-2021 15:20:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:23', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643600220061696', '99626034286166016', '��������', '3', '0', '0', to_date('28-02-2021 15:20:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643643215872000', '99626058474717184', '����', '3', '0', '0', to_date('28-02-2021 15:20:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643661171687424', '99626058474717184', '������', '3', '0', '0', to_date('28-02-2021 15:20:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:20:44', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643747704373248', '99626118348406784', '��ţ�̣�����', '3', '0', '0', to_date('28-02-2021 15:21:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:04', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643797314600960', '99626118348406784', '����Ʒ�����£�', '3', '0', '0', to_date('28-02-2021 15:21:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643836258713600', '99626118348406784', '��ţ��', '3', '0', '0', to_date('28-02-2021 15:21:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:25', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643853656686592', '99626118348406784', '����Ʒ', '3', '0', '0', to_date('28-02-2021 15:21:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643869372743680', '99626118348406784', '��Ʒ����', '3', '0', '0', to_date('28-02-2021 15:21:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:33', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643931301642240', '99626270643585024', 'ˮ��', '3', '0', '0', to_date('28-02-2021 15:21:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643949471367168', '99626270643585024', '�߲�', '3', '0', '0', to_date('28-02-2021 15:21:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:21:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99643979502583808', '99626270643585024', '��������', '3', '0', '0', to_date('28-02-2021 15:22:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:00', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644027720302592', '99626297805897728', '����', '3', '0', '0', to_date('28-02-2021 15:22:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644046754054144', '99626297805897728', '�׿���', '3', '0', '0', to_date('28-02-2021 15:22:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644063984254976', '99626297805897728', '������', '3', '0', '0', to_date('28-02-2021 15:22:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:20', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644082124619776', '99626297805897728', '������', '3', '0', '0', to_date('28-02-2021 15:22:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644146645598208', '99626297805897728', 'ˮ������', '3', '0', '0', to_date('28-02-2021 15:22:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:39', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644194221588480', '99626348473090048', '����', '3', '0', '0', to_date('28-02-2021 15:22:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:51', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644230825279488', '99626348473090048', '���ࣨ�������ĳ���ȵȣ�', '3', '0', '0', to_date('28-02-2021 15:22:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:22:59', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644251146682368', '99626348473090048', '����', '3', '0', '0', to_date('28-02-2021 15:23:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:04', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644269886832640', '99626348473090048', '��������', '3', '0', '0', to_date('28-02-2021 15:23:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:09', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644304120741888', '99626407268843520', 'ֲ����', '3', '0', '0', to_date('28-02-2021 15:23:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644323582312448', '99626407268843520', '������', '3', '0', '0', to_date('28-02-2021 15:23:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:22', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644342536372224', '99626407268843520', '��֬��Ʒ', '3', '0', '0', to_date('28-02-2021 15:23:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644436270678016', '99626430564007936', '���', '3', '0', '0', to_date('28-02-2021 15:23:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644453756731392', '99626430564007936', '����', '3', '0', '0', to_date('28-02-2021 15:23:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644475378368512', '99626430564007936', '��/��/�����ӹ�Ʒ', '3', '0', '0', to_date('28-02-2021 15:23:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:23:58', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644597478752256', '99626475531141120', '������', '3', '0', '0', to_date('28-02-2021 15:24:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:24:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644613849120768', '99626475531141120', '����Ʒ', '3', '0', '0', to_date('28-02-2021 15:24:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:24:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644630437593088', '99626475531141120', '��ʵ��', '3', '0', '0', to_date('28-02-2021 15:24:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:24:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644651056791552', '99626475531141120', '�����ɻ�', '3', '0', '0', to_date('28-02-2021 15:24:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:24:40', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644735345524736', '99626475531141120', '�ɻ�����', '3', '0', '0', to_date('28-02-2021 15:25:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:00', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644771747889152', '99626538688970752', 'ơ��', '3', '0', '0', to_date('28-02-2021 15:25:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:08', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644789212971008', '99626538688970752', '���Ѿ�', '3', '0', '0', to_date('28-02-2021 15:25:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:13', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644813841924096', '99626538688970752', '���ƣ������ͣ�', '3', '0', '0', to_date('28-02-2021 15:25:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644847534768128', '99626538688970752', '�ƾ�', '3', '0', '0', to_date('28-02-2021 15:25:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644868082663424', '99626538688970752', '�̾ƣ������ͣ�', '3', '0', '0', to_date('28-02-2021 15:25:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644892820668416', '99626538688970752', '���', '3', '0', '0', to_date('28-02-2021 15:25:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644934121979904', '99626564047732736', '�׾�', '3', '0', '0', to_date('28-02-2021 15:25:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99644960529317888', '99626564047732736', '�̾ƣ������ͣ�', '3', '0', '0', to_date('28-02-2021 15:25:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:25:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645026417639424', '99626658759311360', '�±�/����', '3', '0', '0', to_date('28-02-2021 15:26:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:09', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645057631649792', '99626658759311360', '����', '3', '0', '0', to_date('28-02-2021 15:26:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645075247726592', '99626658759311360', '���', '3', '0', '0', to_date('28-02-2021 15:26:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:21', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645099713101824', '99626658759311360', '���ɸ������', '3', '0', '0', to_date('28-02-2021 15:26:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645159779729408', '99626693030969344', '��ʳƷ', '3', '0', '0', to_date('28-02-2021 15:26:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645192512077824', '99626693030969344', '�������', '3', '0', '0', to_date('28-02-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645209234767872', '99626693030969344', '�۽��߹���', '3', '0', '0', to_date('28-02-2021 15:26:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645237462433792', '99626693030969344', '���/�۽�����', '3', '0', '0', to_date('28-02-2021 15:26:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:26:59', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645313417084928', '99626717018193920', '����Ʒ', '3', '0', '0', to_date('28-02-2021 15:27:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:27:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645331289014272', '99626717018193920', '����Ʒ', '3', '0', '0', to_date('28-02-2021 15:27:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:27:22', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645350662504448', '99626717018193920', '����Ʒ', '3', '0', '0', to_date('28-02-2021 15:27:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:27:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99645369541066752', '99626717018193920', 'Сʳ����', '3', '0', '0', to_date('28-02-2021 15:27:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:27:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647011917266944', '99627375096102912', '�ֻ�����', '3', '0', '1', to_date('28-02-2021 15:34:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:34:03', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647410179014656', '99627422290411520', '�Ϳ���ֵ', '3', '0', '1', to_date('28-02-2021 15:35:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:35:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647477292072960', '99627493648105472', '��Ƶ��Ա��ֵ', '3', '0', '1', to_date('28-02-2021 15:35:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:35:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647534959558656', '99627522966290432', '���ֻ�Ա��ֵ', '3', '0', '1', to_date('28-02-2021 15:36:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:07', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647589011554304', '99627829951594496', '�ݳ�Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:20', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647604673085440', '99627829951594496', 'չ��/չ��Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647633487953920', '99627829951594496', '��ӰƱ', '3', '0', '1', to_date('28-02-2021 15:36:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647651267608576', '99627829951594496', '��Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647694930313216', '99627850876977152', '�ɻ�Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647729973723136', '99627850876977152', '��Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99647746973237248', '99627850876977152', '����Ʊ', '3', '0', '1', to_date('28-02-2021 15:36:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 15:36:58', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626118348406784', '99621816988991488', '����', '2', '0', '0', to_date('28-02-2021 14:11:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:11:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626270643585024', '99621846110044160', '����', '2', '0', '0', to_date('28-02-2021 14:11:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:11:37', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626297805897728', '99621846110044160', '����ˮ��', '2', '0', '0', to_date('28-02-2021 14:11:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:11:44', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626348473090048', '99621846110044160', '���ݵ���', '2', '0', '0', to_date('28-02-2021 14:11:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:11:56', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626407268843520', '99621879551229952', 'ʳ����', '2', '0', '0', to_date('28-02-2021 14:12:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:12:10', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626430564007936', '99621879551229952', '��/��/����', '2', '0', '0', to_date('28-02-2021 14:12:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:12:16', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626475531141120', '99621879551229952', '�ɻ�', '2', '0', '0', to_date('28-02-2021 14:12:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:12:26', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626538688970752', '99621904318595072', '���;�', '2', '0', '0', to_date('28-02-2021 14:12:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:12:41', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626564047732736', '99621904318595072', '�����', '2', '0', '0', to_date('28-02-2021 14:12:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:12:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626658759311360', '99621937814306816', '���ɸ��', '2', '0', '0', to_date('28-02-2021 14:13:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:13:10', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626693030969344', '99621937814306816', '����Сʳ', '2', '0', '0', to_date('28-02-2021 14:13:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:13:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99626717018193920', '99621937814306816', '��ɺ���Сʳ', '2', '0', '0', to_date('28-02-2021 14:13:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:13:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627057524375552', '99622444788219904', '���ֶһ�ȯ', '2', '0', '1', to_date('28-02-2021 14:14:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:14:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627075673128960', '99622444788219904', 'O2Oȯ��', '2', '0', '1', to_date('28-02-2021 14:14:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:14:49', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627166702108672', '99622466011398144', 'ָ����Ʒ��Ѷһ�ȯ', '2', '0', '1', to_date('28-02-2021 14:15:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:15:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627194489372672', '99622466011398144', 'ָ����Ʒ��ֵ�Ż�ȯ', '2', '0', '1', to_date('28-02-2021 14:15:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:15:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627315721535488', '99622466011398144', 'ר��ͨ����ֵ�Ż�ȯ', '2', '0', '1', to_date('28-02-2021 14:15:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:15:47', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627336198127616', '99622466011398144', 'ƽ̨ͨ����ֵ�Ż�ȯ', '2', '0', '1', to_date('28-02-2021 14:15:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:15:51', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627375096102912', '99622615047602176', '�ֻ�����', '2', '0', '1', to_date('28-02-2021 14:16:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:16:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627422290411520', '99622655812042752', '�Ϳ���ֵ', '2', '0', '1', to_date('28-02-2021 14:16:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:16:12', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627493648105472', '99622718214897664', '��Ƶ��Ա��ֵ', '2', '0', '1', to_date('28-02-2021 14:16:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:16:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627522966290432', '99622718214897664', '���ֻ�Ա��ֵ', '2', '0', '1', to_date('28-02-2021 14:16:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:16:36', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627829951594496', '99622786640773120', '����', '2', '0', '1', to_date('28-02-2021 14:17:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:17:49', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99627850876977152', '99622786640773120', '��ͨ', '2', '0', '1', to_date('28-02-2021 14:17:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:17:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99628258122924032', '99624035918413824', '�ֻ�', '3', '0', '0', to_date('28-02-2021 14:19:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:19:31', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99628634322632704', '99624180202471424', '�ʼǱ�/������', '3', '0', '0', to_date('28-02-2021 14:21:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:21:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99628707043475456', '99624180202471424', 'ƽ�����', '3', '0', '0', to_date('28-02-2021 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99628733035577344', '99624180202471424', '̨ʽ��', '3', '0', '0', to_date('28-02-2021 14:21:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:21:25', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99628754921455616', '99624180202471424', 'һ���', '3', '0', '0', to_date('28-02-2021 14:21:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:21:30', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629252634345472', '99624486604767232', '������/��', '3', '0', '0', to_date('28-02-2021 14:23:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:28', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629059000107008', '99624235982520320', '��ʾ��', '3', '0', '0', to_date('28-02-2021 14:22:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:22:42', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629115199586304', '99624355302080512', 'Ӱ�����㼰���', '3', '0', '0', to_date('28-02-2021 14:22:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:22:56', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629134153646080', '99624355302080512', 'Ӱ���豸', '3', '0', '0', to_date('28-02-2021 14:23:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:00', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629153090928640', '99624355302080512', '��Ϸ�豸', '3', '0', '0', to_date('28-02-2021 14:23:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:05', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629177774407680', '99624355302080512', '�����豸', '3', '0', '0', to_date('28-02-2021 14:23:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629231092400128', '99624486604767232', '���������', '3', '0', '0', to_date('28-02-2021 14:23:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:23', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629313812463616', '99624609556594688', 'ϴ��ˮ', '3', '0', '0', to_date('28-02-2021 14:23:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:23:43', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629418120609792', '99624609556594688', '��Ħ��', '3', '0', '0', to_date('28-02-2021 14:24:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:24:08', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629437028532224', '99624609556594688', '������', '3', '0', '0', to_date('28-02-2021 14:24:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:24:12', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629458809552896', '99624609556594688', 'ϴ����װ', '3', '0', '0', to_date('28-02-2021 14:24:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:24:18', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629486865252352', '99624609556594688', 'Ⱦ��', '3', '0', '0', to_date('28-02-2021 14:24:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:24:24', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99629507912269824', '99624609556594688', '����', '3', '0', '0', to_date('28-02-2021 14:24:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:24:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631069489397760', '99624632553963520', '�۲�����', '3', '0', '0', to_date('28-02-2021 14:30:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:42', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631094546169856', '99624632553963520', '�ֲ�����', '3', '0', '0', to_date('28-02-2021 14:30:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99630959078539264', '99624632553963520', '��ױˮ', '3', '0', '0', to_date('28-02-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99630966234021888', '99624632553963520', '�沿���', '3', '0', '0', to_date('28-02-2021 14:30:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:17', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99630988036014080', '99624632553963520', '����¶/Һ', '3', '0', '0', to_date('28-02-2021 14:30:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:22', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631012077764608', '99624632553963520', '��Һ��˪', '3', '0', '0', to_date('28-02-2021 14:30:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:28', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631036002074624', '99624632553963520', '��Ĥ/����', '3', '0', '0', to_date('28-02-2021 14:30:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:34', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631114737549312', '99624632553963520', '��ɹ��Ʒ', '3', '0', '0', to_date('28-02-2021 14:30:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:52', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631135897812992', '99624632553963520', '������װ', '3', '0', '0', to_date('28-02-2021 14:30:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:30:57', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631177735995392', '99624660945207296', '��ԡ¶', '3', '0', '0', to_date('28-02-2021 14:31:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:07', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631195050082304', '99624660945207296', 'ĥɰ/ԡ��', '3', '0', '0', to_date('28-02-2021 14:31:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:11', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631224573788160', '99624660945207296', '������', '3', '0', '0', to_date('28-02-2021 14:31:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:19', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631258375684096', '99624660945207296', '����', '3', '0', '0', to_date('28-02-2021 14:31:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:27', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631279884075008', '99624660945207296', '����', '3', '0', '0', to_date('28-02-2021 14:31:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:32', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631299148513280', '99624660945207296', '��������', '3', '0', '0', to_date('28-02-2021 14:31:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:36', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631316651343872', '99624660945207296', '��ë��', '3', '0', '0', to_date('28-02-2021 14:31:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:40', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99631334590382080', '99624660945207296', 'ϴҺ', '3', '0', '0', to_date('28-02-2021 14:31:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:31:45', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632024654053376', '99624660945207296', '���㻤��', '3', '0', '0', to_date('28-02-2021 14:34:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:34:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632047299100672', '99624660945207296', '������װ', '3', '0', '0', to_date('28-02-2021 14:34:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:34:35', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632104131919872', '99624730490961920', '����/����/����ˮ', '3', '0', '0', to_date('28-02-2021 14:34:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:34:48', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632130249850880', '99624730490961920', '��ˢ/����', '3', '0', '0', to_date('28-02-2021 14:34:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:34:54', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632156355198976', '99624730490961920', '��ǻ������װ', '3', '0', '0', to_date('28-02-2021 14:35:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:01', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632176060039168', '99624730490961920', '�������²�Ʒ', '3', '0', '0', to_date('28-02-2021 14:35:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:05', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632195995566080', '99624730490961920', '��ǻ����', '3', '0', '0', to_date('28-02-2021 14:35:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:10', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632276119355392', '99624805090852864', 'Ƥ������', '3', '0', '0', to_date('28-02-2021 14:35:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:29', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632293135646720', '99624805090852864', '���뻤��', '3', '0', '0', to_date('28-02-2021 14:35:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:33', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632329869361152', '99624831728877568', 'ͷ������', '3', '0', '0', to_date('28-02-2021 14:35:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:42', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632347061813248', '99624831728877568', '���廤��', '3', '0', '0', to_date('28-02-2021 14:35:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:46', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632377764118528', '99624831728877568', '���', '3', '0', '0', to_date('28-02-2021 14:35:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:35:53', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');

insert into PMS_PRODUCT_CATEGORY (ID, PARENT_ID, CATEGORY_NAME, CATEGORY_LEVEL, CATEGORY_SORT, CATEGORY_TYPE, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('99632431258271744', '99624906672701440', '�����', '3', '0', '0', to_date('28-02-2021 14:36:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-02-2021 14:36:06', 'dd-mm-yyyy hh24:mi:ss'), 'ϵͳ����Ա', 'ϵͳ����Ա');
prompt Done.
