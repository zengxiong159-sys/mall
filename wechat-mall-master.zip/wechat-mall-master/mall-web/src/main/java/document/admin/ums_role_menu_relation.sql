
insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283121803264', '101464407145578496', '1', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283138580480', '101464407145578496', '2', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283146969088', '101464407145578496', '3', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283155357696', '101464407145578496', '4', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283159552000', '101464407145578496', '5', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283172134912', '101464407145578496', '6', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283176329216', '101464407145578496', '7', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283176329217', '101464407145578496', '8', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283184717824', '101464407145578496', '9', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283188912128', '101464407145578496', '10', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283197300736', '101464407145578496', '11', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283201495040', '101464407145578496', '12', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283205689344', '101464407145578496', '13', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283209883648', '101464407145578496', '14', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283214077952', '101464407145578496', '15', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283218272256', '101464407145578496', '16', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283218272257', '101464407145578496', '17', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283226660864', '101464407145578496', '18', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283226660865', '101464407145578496', '19', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283230855168', '101464407145578496', '20', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283235049472', '101464407145578496', '21', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283239243776', '101464407145578496', '22', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283243438080', '101464407145578496', '23', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283247632384', '101464407145578496', '24', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283251826688', '101464407145578496', '25', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283256020992', '101464407145578496', '26', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283276992512', '101464407145578496', '27', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283260215296', '101464407145578496', '28', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283264409600', '101464407145578496', '29', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283268603904', '101464407145578496', '30', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133272283272798208', '101464407145578496', '31', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_role_menu_relation (ID, ROLE_ID, MENU_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('133172893272796209', '101464407145578496', '32', to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-06-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');
