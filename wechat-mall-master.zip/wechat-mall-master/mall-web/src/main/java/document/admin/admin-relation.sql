insert into ums_admin_role_relation (ID, ADMIN_ID, ROLE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('120640118276182016', '3', '101464407145578496', to_date('27-04-2021 13:53:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-04-2021 13:53:09', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');

insert into ums_admin_role_relation (ID, ADMIN_ID, ROLE_ID, CREATE_TIME, UPDATE_TIME, CREATED_BY, UPDATED_BY)
values ('120640118376845312', '3', '90562006935011328', to_date('27-04-2021 13:53:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-04-2021 13:53:09', 'dd-mm-yyyy hh24:mi:ss'), '系统管理员', '系统管理员');
