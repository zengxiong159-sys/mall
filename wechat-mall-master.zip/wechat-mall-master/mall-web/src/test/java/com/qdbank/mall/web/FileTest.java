package com.qdbank.mall.web;

import java.io.*;

public class FileTest {
    public static void main(String[] args) {
        String inurl = "D:\\1.txt";
        File infile = new File(inurl);
        String outurl = "D:\\2.txt";
        File outfile = new File(outurl);
        try {
            //���д����ļ������ڴ������ļ�
            if (!outfile.exists()) {
                outfile.createNewFile();
            }
            //�ļ�����������ȡ�ļ�
            FileInputStream in = new FileInputStream(infile);
            FileOutputStream out = new FileOutputStream(outfile);
            //���ļ�
            BufferedReader read = new BufferedReader(new InputStreamReader(in));
            //д�ļ�
            BufferedWriter write = new BufferedWriter(new OutputStreamWriter(out));

            String temp = "";

            while ((temp = read.readLine()) != null) {
                //д���ļ�
                write.write(temp + "\r\n" + "commit;" + "\r\n" );
            }
            read.close();
            write.close();
            out.close();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
